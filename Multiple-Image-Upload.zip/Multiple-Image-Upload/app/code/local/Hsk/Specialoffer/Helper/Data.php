<?php
/**
 * Specialoffer helper
 *
 * @category    Hsk
 * @package     Hsk_Specialoffer
 * @author      <hiren.kava84@gmail.com>
 */
class Hsk_Specialoffer_Helper_Data extends Mage_Core_Helper_Abstract
{
	public function getSpecialOfferUrl()
	{
		return Mage::getUrl("specialoffer");
	}
	
	public function log($message='')
	{
		if(isset($message) && $message != '') {
			Mage::log($message,null,'specialoffer.log');
		}
	}
	
	public function getPreviousDay()
	{
		$currentDateTime = now();
		$currentYear = date('Y',strtotime($currentDateTime));
		$currentMonth = date('m',strtotime($currentDateTime));
		$currentDay = date('d',strtotime($currentDateTime));
		$currentHour = date('H',strtotime($currentDateTime));
		$currentMinute = date('i',strtotime($currentDateTime));
		$currentSecond = date('s',strtotime($currentDateTime));		
		$previousDay = date('Y-m-d H:i:s',mktime($currentHour,$currentMinute,$currentSecond,$currentMonth,$currentDay-1,$currentYear));
		return $previousDay;
	}
	
	public function encryptParams($stringArray, $key = "specialoffer")
	{
		 $s = base64_encode(serialize($stringArray));
		 return '?specialoffer='.$s;
		// $s = strtr(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), serialize($stringArray), MCRYPT_MODE_CBC, md5(md5($key)))), '+/=', '-_,');
	    // return '?specialoffer='.$s;
	}
	
	public function decryptParams($stringArray, $key = "specialoffer")
	{
		$s = unserialize(base64_decode($stringArray));
		return $s;
		//$stringArray = substr($stringArray,1,strlen($stringArray));
		//$s = unserialize(rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), base64_decode(strtr($stringArray, '-_,', '+/=')), MCRYPT_MODE_CBC, md5(md5($key))), "\0"));
	    //return $s;
	}
	
	/**
*Function to encrypt or decrypt the given value
* @param string
* @return string
*/
public function encrypt_decrypt($string) {
   
    $string_length=strlen($string); 
    $encrypted_string=""; 
    /**
    *For each character of the given string generate the code
    */
    for ($position = 0;$position<$string_length;$position++){         
        $key = (($string_length+$position)+1);
        $key = (255+$key) % 255;
        $get_char_to_be_encrypted = SUBSTR($string, $position, 1); 
        $ascii_char = ORD($get_char_to_be_encrypted); 
        $xored_char = $ascii_char ^ $key;  //xor operation 
        $encrypted_char = CHR($xored_char); 
        $encrypted_string .= $encrypted_char; 
    } 
    /**
    *Return the encrypted/decrypted string
    */
    return $encrypted_string; 
 }
}
	 