<?php
$installer = $this;
$installer->startSetup();
$installer->run("
CREATE TABLE IF NOT EXISTS {$this->getTable('specialoffer/specialoffer')} (
  `id` int(11) unsigned NOT NULL auto_increment,
  `product_id` int (11) NOT NULL default '0',
  `email_address` varchar (255) not null default '',
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;"
);

$installer->addAttribute("catalog_product", "show_special_price",  array(
                    'group'         => 'Prices', 
                    'type'          => 'int',
//                    'attribute_set' =>  'Price',
                    'backend'       => '',
                    'frontend'      => '',
                    'label'         => 'Show SpecialOffer',
                    'input'         => 'select',
                    'global'        => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
                    'backend'    => 'eav/entity_attribute_backend_array',
                    'visible'       => true,
                    'required'      => false,
                    'user_defined'  => true,
                    'default'       => '0',
                    'visible_on_front' => false,
                    'used_in_product_listing' => true,
                    'apply_to' => 'simple',
                    'sort_order'    => 29,
                    'is_configurable' => 0,
                    'option'     => array (
                        'values' => array(
                            0 => 'Hide',
                            1 => 'Show',
                        )
                    ),

    ));
	
$installer->addAttribute('catalog_product', 'specialoffer_price', array( 
'group' => 'Prices',
'input' => 'price',
'type' => 'decimal',
'apply_to' => 'simple',
'label' => 'SpecialOffer Price',
'backend' => '',
'visible' => 1,
'required' => 0,
'user_defined' => 1,
'searchable' => 0,
'filterable' => 0,
'sort_order' => 30,
'comparable' => 0,
'visible_on_front' => 0,
'visible_in_advanced_search' => 0,
'is_html_allowed_on_front' => 0,
'is_configurable' => 0,
'used_in_product_listing' => true,
'global' => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL, )); 	
$installer->endSetup();