<?php   
class Hsk_Specialoffer_Block_Specialoffer extends Mage_Core_Block_Template
{
	public function getFormAction()
	{
		return $this->getUrl('specialoffer/index/post');
	}	
}