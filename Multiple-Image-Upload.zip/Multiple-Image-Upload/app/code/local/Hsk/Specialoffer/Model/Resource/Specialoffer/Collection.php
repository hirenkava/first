<?php

/**
 * Specialoffer price resource collection model
 *
 * @category    Hsk
 * @package     Hsk_Specialoffer
 * @author      <hiren.kava84@gmail.com>
 */
class Hsk_Specialoffer_Model_Resource_Specialoffer_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{
	public function _construct(){
		$this->_init("specialoffer/specialoffer");
	}
}
	 