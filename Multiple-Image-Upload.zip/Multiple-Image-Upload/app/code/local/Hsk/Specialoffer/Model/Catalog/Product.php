<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category    Mage
 * @package     Mage_Catalog
 * @copyright   Copyright (c) 2014 Magento Inc. (http://www.magentocommerce.com)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Catalog product model
 *
 * @method Mage_Catalog_Model_Resource_Product getResource()
 * @method Mage_Catalog_Model_Product setHasError(bool $value)
 * @method null|bool getHasError()
 *
 * @category    Mage
 * @package     Mage_Catalog
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Hsk_Specialoffer_Model_Catalog_Product extends Mage_Catalog_Model_Product
{
    /**
     * Get product final price
     *
     * @param double $qty
     * @return double
     */
    public function getFinalPrice($qty=null)
    {
        $price = $this->_getData('final_price');
        if ($price !== null) {
            return $price;
        }

		$email_address = '';
		$pid = 0;		
		$specialOffer = Mage::app()->getRequest()->getParam('specialoffer','');
		if($specialOffer != '') {
			$decryptedParams = Mage::helper("specialoffer")->decryptParams($specialOffer);
			//print_r($decryptedParams);die;
			$email_address = $decryptedParams['email'];
			$pid = $decryptedParams['pid'];
		}	
		//echo $email_address.' '.	$pid;
		$canApproveSpecialOffer = Mage::getResourceModel("specialoffer/specialoffer")->getSpecialOfferByEmailAndProductId($email_address,$pid);
		if($pid && $email_address && $pid == $this->getId() && isset($canApproveSpecialOffer['id'])) {
		$specialPrice = $this->getSpecialPrice();
			if($this->getAttributeText('show_special_price') == Hsk_Specialoffer_Model_Specialoffer::SHOW_SPECIALOFFER && $this->getSpecialofferPrice() && $this->getPrice() > $this->getSpecialofferPrice()) {
			if(isset($specialPrice) && $specialPrice != '') {			
				if($specialPrice > $this->getSpecialofferPrice()) {
					Mage::getSingleton('checkout/session')->setEmailAddress($email_address);
					Mage::getSingleton('checkout/session')->setPid($pid);
					$productIds = (array)Mage::getSingleton('checkout/session')->getProductIds();
					if(!in_array($this->getId(),$productIds)) {
						$productIds = array_merge($productIds,array($this->getId()));
						Mage::getSingleton('checkout/session')->setProductIds($productIds);
					}
				}
			}else{
				Mage::getSingleton('checkout/session')->setEmailAddress($email_address);
				Mage::getSingleton('checkout/session')->setPid($pid);
				$productIds = (array)Mage::getSingleton('checkout/session')->getProductIds();
				if(!in_array($this->getId(),$productIds)) {
					$productIds = array_merge($productIds,array($this->getId()));
					Mage::getSingleton('checkout/session')->setProductIds($productIds);
				}
			}
				//Mage::log(' params '.$pid.' && '.$email_address,null,'hsk.log');
				
				//return $this->getPriceModel()->getFinalPrice($qty, $this);
				//return $this->getSpecialofferPrice();//
				return (($this->getPriceModel()->getFinalPrice($qty, $this) - $this->getPriceModel()->getBasePrice($this, $qty)) + $this->getSpecialofferPrice());
			}else{
				return $this->getPriceModel()->getFinalPrice($qty, $this);
			}
		}else{//Mage::log($this->getPriceModel()->getFinalPrice($qty, $this),null,'hsk.log');
	        return $this->getPriceModel()->getFinalPrice($qty, $this);
		}
    }
	
	public function getFinalPrice1($qty=null)
    {
        $price = $this->_getData('final_price');
        if ($price !== null) {
            return $price;
        }		
		$specialOffer = Mage::app()->getRequest()->getParam('specialoffer','');
		$decryptedParams = Mage::helper("specialoffer")->decryptParams();
		$email_address = Mage::app()->getRequest()->getParam('email_address','');
		$pid = Mage::app()->getRequest()->getParam('pid',0);
		$canApproveSpecialOffer = Mage::getResourceModel("specialoffer/specialoffer")->getSpecialOfferByEmailAndProductId($email_address,$pid);
		if($pid && $email_address && $pid == $this->getId() && isset($canApproveSpecialOffer['id'])) {
			if($this->getAttributeText('show_special_price') == Hsk_Specialoffer_Model_Specialoffer::SHOW_SPECIALOFFER && $this->getSpecialofferPrice() && $this->getPrice() > $this->getSpecialofferPrice() && $this->getSpecialPrice() > $this->getSpecialofferPrice()) {
				//Mage::log(' params '.$pid.' && '.$email_address,null,'hsk.log');
				Mage::getSingleton('checkout/session')->setEmailAddress($email_address);
				Mage::getSingleton('checkout/session')->setPid($pid);
				return $this->getPriceModel()->getFinalPrice($qty, $this);
				//return $this->getSpecialofferPrice();//(($this->getPriceModel()->getFinalPrice($qty, $this) - $this->getPriceModel()->getBasePrice($this, $qty)) + 3);
			}else{
				return $this->getPriceModel()->getFinalPrice($qty, $this);
			}
		}else{//Mage::log($this->getPriceModel()->getFinalPrice($qty, $this),null,'hsk.log');
	        return $this->getPriceModel()->getFinalPrice($qty, $this);
		}
    }
}
