<?php
/**
 * Specialoffer price resource model
 *
 * @category    Hsk
 * @package     Hsk_Specialoffer
 * @author      <hiren.kava84@gmail.com>
 */
class Hsk_Specialoffer_Model_Resource_Specialoffer extends Mage_Core_Model_Resource_Db_Abstract
{
    protected function _construct()
    {
        $this->_init("specialoffer/specialoffer", "id");
    }
	
	/**
     * get special offer customer
     *
     * @param  $email_address, $product_id
     * @return $row;
     */
	 
	 public function getSpecialOfferByEmailAndProductId($email_address='',$product_id=0)
	 {
	 	$previousDay = Mage::helper("specialoffer")->getPreviousDay();
	 	$read = $this->_getReadAdapter();
		$select = $read->select()
			           ->from(array('main_table' => $this->getMainTable()))            
			           ->where('product_id = ?', $product_id)
					   ->where('added_date > ?', $previousDay)
					   ->where('email_address = ?', $email_address);			   
		$rs = $read->fetchRow($select);
		return $rs;
	 }
	
	
	/**
     * exists special offer entry for paticular email address before saving
     *
     * @param  Hsk_Specialoffer_Model_Specialoffer $object
     * @return
     */
    protected function _beforeSave(Mage_Core_Model_Abstract $object)
    {
		$data = Mage::app()->getRequest()->getPost();
		$rs = $this->getSpecialOfferByEmailAndProductId($data['email_address'],$data['product_id']);
		if(isset($rs['id'])) {
			$redirectUrl = Mage::getUrl('specialoffer',array('pid'=>$data['product_id']));
			$errors[] = Mage::helper("specialoffer")->__('You have already subscribed this product within 24 hours. try after complete 24 hours.');
			$this->sendErrorResponse($redirectUrl,$errors);			
		}
	}
	
	/**
     * send mail after save
     *
     * @param  Hsk_Specialoffer_Model_Specialoffer $object
     * @return
     */
    protected function _afterSave(Mage_Core_Model_Abstract $object)
    {
		$this->sendSpecialOfferMail($object);
	}
	
	/**
     * send mail after save
     *
     * @param  Hsk_Specialoffer_Model_Specialoffer $object
     * @return
     */
	 public function sendSpecialOfferMail($object)
	 {
	 	$templateId = 'special_offer_email_template';
		// Set sender information
		$senderName = Mage::getStoreConfig('trans_email/ident_support/name');
		$senderEmail = Mage::getStoreConfig('trans_email/ident_support/email');
		$sender = array('name' => $senderName,'email' => $senderEmail);
		// Set recepient information
		$recepientEmail = $object->getEmailAddress();
		
		// Get Store ID
		$store = Mage::app()->getStore()->getId();
		// load product model to send email template
		$product = Mage::getModel("catalog/product")->load($object->getProductId());
		$_store = $product->getStore();
		$_coreHelper = Mage::helper('core');
		$post = array();
		$post['name'] = $product->getName();
		$post['sku'] = $product->getSku();
		$post['specialoffer_price'] = $_coreHelper->formatPrice($_store->roundPrice($_store->convertPrice($product->getSpecialofferPrice())));
		$post['short_description'] = $product->getShortDescription();
		$encryptedParams = Mage::helper("specialoffer")->encryptParams(array('pid'=>$object->getProductId(),'email'=>$object->getEmailAddress()));
		$post['specialoffer_url'] = $product->getProductUrl().$encryptedParams;
		$postObject = new Varien_Object();
		$postObject->setData($post);	
		// Set variables that can be used in email template
		$vars = array('product'=>$postObject);		
		
		$translate = Mage::getSingleton(�core/translate�);
		// set email subject string
		$mailSubject = Mage::helper("specialoffer")->__('Your topmobility.com Special Offer has arrived!');
		// load email template model
		$mailTemplate = Mage::getModel('core/email_template');
		// set email subject
		$mailTemplate->setTemplateSubject($mailSubject);
		// Send Transactional Email
		try{			
			$mailTemplate->sendTransactional($templateId, $sender, $recepientEmail, '', $vars, $storeId);
		}catch(Exception $e){
			print_r($e);
		}		
	 }
	
	/**
     * send error message and redirect to given url
     *
     * @param  $redirectUrl, $errors
     * @return
     */	
	public function sendErrorResponse($redirectUrl,$errors) 
	{
		$errors = (is_array($errors)) ? implode('\n',$errors) : $errors;
    	 Mage::getSingleton('core/session')->addError($errors);
		 Mage::app()->getFrontController()->getResponse()->setRedirect($redirectUrl);
		 Mage::app()->getResponse()->sendResponse();
		 exit;
	}
	
	/**
     * delete expired (before 24 hours) special offer entries
     *
     * @param  $oneDayBefore
     * @return
     */
	
	public function deleteExpiredEntries($oneDayBefore)
	{
		$write = $this->_getWriteAdapter();
		$condition = array(
                'added_date <= ?' => $oneDayBefore,
            );
		try {
			$write->delete($this->getMainTable(), $condition);
		} catch(Exception $e) {
			Mage::helper("specialoffer")->log($e->getMessage());
		}
	}
}