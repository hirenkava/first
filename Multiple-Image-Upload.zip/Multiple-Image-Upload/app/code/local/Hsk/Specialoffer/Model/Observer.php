<?php

class Hsk_Specialoffer_Model_Observer
{	//https://www.ybizz.com/blog/add-product-to-cart-with-custom-price-in-magento/#.Vz_yFjV96M-
	/**
 * @param Varien_Event_Observer $observer
 */
public function applyDiscount(Varien_Event_Observer $observer)
{ 
//return;
    /* @var $item Mage_Sales_Model_Quote_Item */
	$quote = $observer->getQuote(); 
    $item = $observer->getQuoteItem();
    if ($item->getParentItem()) {
        $item = $item->getParentItem();
    }
	$email_address = Mage::getSingleton('checkout/session')->getEmailAddress();
	$pid =	Mage::getSingleton('checkout/session')->getPid();
	//echo $email_address.' '.	$pid;die;
	$canApproveSpecialOffer = Mage::getResourceModel("specialoffer/specialoffer")->getSpecialOfferByEmailAndProductId($email_address,$item->getProduct()->getId());
	if(isset($canApproveSpecialOffer['id'])) {
		$product = Mage::getModel("catalog/product")->load($item->getProduct()->getId());
//		echo $item->getProduct()->getFinalPrice() .'-'. $this->getPriceModel($product)->getBasePrice($product, $item->getQty()).' *** '.$item->getQty();die;
//echo $product->getTierPriceCount();die;
		if($product->getTierPriceCount() == 0 && $product->getAttributeText('show_special_price') == Hsk_Specialoffer_Model_Specialoffer::SHOW_SPECIALOFFER && $product->getSpecialofferPrice()) {
			$specialPrice = (($item->getProduct()->getFinalPrice() - $this->getPriceModel($product)->getBasePrice($product, $item->getQty())) + $product->getSpecialofferPrice());		
			// Make sure we don't have a negative
			if ($specialPrice > 0) {
				$item->setCustomPrice($specialPrice);
				$item->setOriginalCustomPrice($specialPrice);
				$item->getProduct()->setIsSuperMode(true);
			}
		}
	}    
}

	public function validateSpecialOffer(Varien_Event_Observer $observer)
	{
	return;
		$params = Mage::app()->getRequest()->getParams();
		//echo '<pre>';print_r($params);die;
		echo $email_address = Mage::app()->getRequest()->getParam('email','');
		$pid = Mage::app()->getRequest()->getParam('pid',0);
		$session_email_address = Mage::getSingleton('checkout/session')->getEmailAddress();
		//$session_pid =	Mage::getSingleton('checkout/session')->getPid();
		$productIds = (array)Mage::getSingleton('checkout/session')->getProductIds();
		$product_id = Mage::app()->getRequest()->getParam('product','');
		//print_r($productIds);echo $pid.' ** '.$product_id;die;
			$_cartProductIds = array();
			$quote = Mage::getSingleton('checkout/cart')->getQuote();
			 foreach($quote->getAllItems() as $_item) {
			 	$_cartProductIds[] = $_item->getProductId();
			 }
		if($pid && $email_address != '' && !in_array($product_id,$_cartProductIds)) {
				$productFound = false;
				 $quote = Mage::getSingleton('checkout/cart')->getQuote();
				 foreach($quote->getAllItems() as $_item) {
					if($_item->getProductId() == $product_id) {
						$productFound = true;
						break;	
					}
				 }
				//$productIds = array_merge($_cartProductIds,array($product_id=>($productFound) ? ));
				Mage::getSingleton('checkout/session')->setCartProductIds($productIds);
		}
		if((!$pid && $email_address == '') && ($session_email_address != '' && (in_array($product_id,$productIds) || in_array($pid,$productIds)))) {
			 /*$product = Mage::getModel('catalog/product')
				    ->setStoreId(Mage::app()->getStore()->getId())
				    ->load($product_id);*/
			 $productFound = false;
			 $quote = Mage::getSingleton('checkout/cart')->getQuote();
			 foreach($quote->getAllItems() as $_item) {
			 	if($_item->getProductId() == $product_id) {
			 		$productFound = true;
			 		break;	
			 	}
			 }
		   if ($productFound !== false)  {
				Mage::getSingleton('checkout/session')->addError(Mage::helper("specialoffer")->__('You have already added this product in cart with special price offer/normal url so you can\'t add from normal url.<br/>
				try again with special price offer url or remove special price offer product from cart.'));
				$url = Mage::helper('core/http')->getHttpReferer() ? Mage::helper('core/http')->getHttpReferer()  : Mage::getUrl();
				Mage::app()->getFrontController()->getResponse()->setRedirect($url);
				Mage::app()->getResponse()->sendResponse();
				exit;
			}
		}
	}	
	
	public function unsetSpecialPriceOfferVariables(Varien_Event_Observer $observer)
	{
		$itemId = Mage::app()->getRequest()->getParam('id',0);
		if($itemId) {
			$itemObject = Mage::getModel('sales/quote_item')->load($itemId);
			$productIds = (array)Mage::getSingleton('checkout/session')->getProductIds();
			if(in_array($itemObject->getProductId(),$productIds)) {
				$key = array_search($itemObject->getProductId(),$productIds);
				if($key) {
					unset($productIds[$key]);
				}
				Mage::getSingleton('checkout/session')->setProductIds($productIds);
				Mage::getSingleton('checkout/session')->unsEmailAddress();
			}
		}
	}
	
	/**
     * Get product price model
     *
     * @return Mage_Catalog_Model_Product_Type_Price
     */
    public function getPriceModel($product)
    {
        return Mage::getSingleton('catalog/product_type')->priceFactory($product->getTypeId());
    }
	
	public function deleteSpecialOfferExpiredEntries(/*Varien_Event_Observer $observer*/)
	{
		$previousDay = Mage::helper("specialoffer")->getPreviousDay();
		Mage::getResourceModel("specialoffer/specialoffer")->deleteExpiredEntries($previousDay);		
	}

}