<?php
/**
 * Specialoffer price model
 *
 * @category    Hsk
 * @package     Hsk_Specialoffer
 * @author      <hiren.kava84@gmail.com>
 */

class Hsk_Specialoffer_Model_Specialoffer extends Mage_Core_Model_Abstract
{
	const SHOW_SPECIALOFFER = 'Show';
	const HIDE_SPECIALOFFER = 'Hide';
    protected function _construct(){

       $this->_init("specialoffer/specialoffer");

    }
}
	 