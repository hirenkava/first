<?php
class Hsk_Specialoffer_IndexController extends Mage_Core_Controller_Front_Action
{	
    public function indexAction() {     
	  $product_id = $this->getRequest()->getParam('pid',0);
	  $product = Mage::getModel("catalog/product")->load($product_id); 
	  if($product->getAttributeText('show_special_price') == Hsk_Specialoffer_Model_Specialoffer::SHOW_SPECIALOFFER && $product->getSpecialofferPrice()) {
		  $this->loadLayout();   
		  $this->getLayout()->getBlock("head")->setTitle($this->__("Special Offer"));
				$breadcrumbs = $this->getLayout()->getBlock("breadcrumbs");
		  $breadcrumbs->addCrumb("home", array(
					"label" => $this->__("Home Page"),
					"title" => $this->__("Home Page"),
					"link"  => Mage::getBaseUrl()
			   ));
	
		  $breadcrumbs->addCrumb("titlename", array(
					"label" => $this->__("Special Offer"),
					"title" => $this->__("Special Offer")
			   ));
	
		  $this->renderLayout(); 
	  }else{
	  	 $this->_redirect('');
		 return;
	  }	  
    }
	
	public function postAction()
	{
		$data = $this->getRequest()->getPost();
		$data['added_date'] = now();
		try{
			 $specialOfferModel = Mage::getModel("specialoffer/specialoffer")->load(null);
			 $specialOfferModel->setData($data);
			 $specialOfferModel->save();			 
			 $this->_redirect('*/*/specialoffersuccess',array('id'=>$data['id']));
		}catch(Exception $e) {
			Mage::getSingleton('customer/session')->addError(Mage::helper('contacts')->__('Unable to submit your request. Please, try again.'));
                $this->_redirect('*/*/',array('id'=>$data['id']));
                return;
		}
	}
	
	public function specialoffersuccessAction()
	{
		$this->loadLayout();
		$this->renderLayout(); 
	}
}