<?php
$installer = $this;
$installer->startSetup();
$installer->run("
CREATE TABLE {$this->getTable('locations/locations')} (
  `location_id` int(11) unsigned NOT NULL auto_increment,
  `location_name` varchar (255) NOT NULL default '',
  `url_key` varchar (255) not null default '',
  `address` text,
  `logo`  varchar (255) not null default '',
  `parking` text,
  `the_vibe` text,
  `postcode` varchar(100) NOT NULL DEFAULT '',
  `opening_times` varchar(255) NOT NULL default '',
  `latitude` varchar(100) NOT NULL default '',
  `longitude` varchar(100) NOT NULL default '',
  `added_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `country` varchar(255) NOT NULL default '', 
  `phone` varchar (50),
  `status`  smallint(2) not null default '1',
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE {$this->getTable('locations/locationsimage')} (
  `locationsimage_id` int(11) unsigned NOT NULL auto_increment,
  `location_id` int(11) unsigned NOT NULL DEFAULT '0',
  `image` varchar (255) NOT NULL default '',
  `sort_order`  int(5) NOT NULL DEFAULT '0',
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`locationsimage_id`)  
) ENGINE=InnoDB DEFAULT CHARSET=utf8;"
);
$installer->endSetup();

/**/