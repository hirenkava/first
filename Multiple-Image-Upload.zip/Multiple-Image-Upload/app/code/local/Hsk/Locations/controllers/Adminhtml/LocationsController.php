<?php

class Hsk_Locations_Adminhtml_LocationsController extends Mage_Adminhtml_Controller_Action
{
		protected function _initAction()
		{
				$this->loadLayout()->_setActiveMenu("locations/locations")->_addBreadcrumb(Mage::helper("adminhtml")->__("Locations  Manager"),Mage::helper("adminhtml")->__("Locations Manager"));
				return $this;
		}
		public function indexAction() 
		{
			    $this->_title($this->__("Locations"));
			    $this->_title($this->__("Manager Locations"));

				$this->_initAction();
				$this->renderLayout();
		}
		public function editAction()
		{			    
			    $this->_title($this->__("Locations"));
				$this->_title($this->__("Locations"));
			    $this->_title($this->__("Edit Item"));
				
				$id = $this->getRequest()->getParam("id");
				$model = Mage::getModel("locations/locations")->load($id);
				if ($model->getId()) {
					Mage::register("locations_data", $model);
					$this->loadLayout();
					$this->_setActiveMenu("locations/locations");
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Locations Manager"), Mage::helper("adminhtml")->__("Locations Manager"));
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Locations Description"), Mage::helper("adminhtml")->__("Locations Description"));
					$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);
					$this->_addContent($this->getLayout()->createBlock("locations/adminhtml_locations_edit"))->_addLeft($this->getLayout()->createBlock("locations/adminhtml_locations_edit_tabs"));
					$this->renderLayout();
				} 
				else {
					Mage::getSingleton("adminhtml/session")->addError(Mage::helper("locations")->__("Item does not exist."));
					$this->_redirect("*/*/");
				}
		}

		public function newAction()
		{

		$this->_title($this->__("Locations"));
		$this->_title($this->__("Locations"));
		$this->_title($this->__("New Item"));

        $id   = $this->getRequest()->getParam("id");
		$model  = Mage::getModel("locations/locations")->load($id);

		$data = Mage::getSingleton("adminhtml/session")->getFormData(true);
		if (!empty($data)) {
			$model->setData($data);
		}

		Mage::register("locations_data", $model);

		$this->loadLayout();
		$this->_setActiveMenu("locations/locations");

		$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);

		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Locations Manager"), Mage::helper("adminhtml")->__("Locations Manager"));
		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Locations Description"), Mage::helper("adminhtml")->__("Locations Description"));


		$this->_addContent($this->getLayout()->createBlock("locations/adminhtml_locations_edit"))->_addLeft($this->getLayout()->createBlock("locations/adminhtml_locations_edit_tabs"));

		$this->renderLayout();

		}
		public function saveAction()
		{
			$post_data=$this->getRequest()->getPost();
			$files = $_FILES;
			//echo Mage::helper("locations")->getImagePath();//die;
			//echo '<pre>';print_r($post_data);print_r($files);die;
			if ($post_data) {
					try {
					/*if(isset($_FILES['fileinputname']['name']) and (file_exists($_FILES['fileinputname']['tmp_name']))) {
					  try {
						$uploader = new Varien_File_Uploader('fileinputname');
						$uploader->setAllowedExtensions(array('jpg','jpeg','gif','png')); // or pdf or anything				 
						$uploader->setAllowRenameFiles(false);					 
						// setAllowRenameFiles(true) -> move your file in a folder the magento way
						// setAllowRenameFiles(true) -> move your file directly in the $path folder
						$uploader->setFilesDispersion(false);					   
						$path = Mage::getBaseDir('media') . DS ;								   
						$uploader->save($path, $_FILES['fileinputname']['name']);					 
						$data['fileinputname'] = $_FILES['fileinputname']['name'];
					  }catch(Exception $e) {
					 	//->addData($post_data)
					  }
					}*/
						
						$model = Mage::getModel("locations/locations")
								->setId($this->getRequest()->getParam("id"));
						$model->setLocationName($post_data['location_name']);
						$model->setPhone($post_data['phone']);
						$model->setUrlKey($post_data['url_key']);
						$model->setCountry($post_data['country']);
						$model->setAddress($post_data['address']);
						$model->setParking($post_data['parking']);
						$model->setTheVibe($post_data['the_vibe']);
						$model->setPostcode($post_data['postcode']);
						$model->setOpeningTimes($post_data['opening_times']);
						$model->setLatitude($post_data['latitude']);
						$model->setLongitude($post_data['longitude']);
						$model->setStatus($post_data['status'])						
						->setAddedDate(now())
						->setUpdatedDate(now());
						if(isset($files['logo']['name']) && $files['logo']['name'] != '') {
							$logoName = time().$files['logo']['name'];
							copy($files['logo']['tmp_name'],Mage::helper("locations")->getLogoPath().$logoName);
							$model->setLogo($logoName);
						}
						if(isset($post_data['logo']['delete']) && $post_data['logo']['delete'] == 1)  {
							$model->setLogo('');
							unlink(Mage::helper("locations")->getLogoPath().$post_data['logo']['value']);
						}
					        
						$model->save();
						$deleteImages = array();
						if(isset($post_data['delete_image']) && $post_data['delete_image'] != '') {
							$deleteIds = substr($post_data['delete_image'],0,-1);
							$deleteImages = explode(",",$deleteIds);
						}
						$noOfImage = $post_data['no_of_image'];
						if($noOfImage > 0) {
							for($i=1;$i<=$noOfImage;$i++) {
								if(isset($files['file_'.$i]['name']) && $files['file_'.$i]['name'] != '') {
									$imageName = time().'_'.$files['file_'.$i]['name'];
									@copy($files['file_'.$i]['tmp_name'],Mage::helper("locations")->getGalleryPath().$imageName);
									$id = null;
									if(isset($post_data['locationsimage_id'][$i]) && isset($post_data['oldimage'][$i])) {
										$id = $post_data['locationsimage_id'][$i];
									}
									if(count($deleteImages) > 0) {
										for($di=0;$di<count($deleteImages);$di++) {
											if($deleteImages[$di] == $post_data['locationsimage_id'][$i]) {
												$id = null;
												break;
											}
										}
									}
									//echo $id;die;
									$imageModel = Mage::getModel("locations/locationsimage")->load($id);
									$imageModel->setSortOrder($post_data['sort_order_'.$i]);
									$imageModel->setImage($imageName);
									$imageModel->setLocationId($model->getId());
									$imageModel->setAddedDate(now());
									$imageModel->save();
									if(isset($post_data['locationsimage_id'][$i]) && isset($post_data['oldimage'][$i])) {
										unlink(Mage::helper("locations")->getGalleryPath().$post_data['oldimage'][$i]);
									}
								}else{
									if($post_data['locationsimage_id'][$i] && $post_data['oldimage'][$i]) {
										$imageModel = Mage::getModel("locations/locationsimage")->load($post_data['locationsimage_id'][$i]);
										$imageModel->setSortOrder($post_data['sort_order_'.$i]);
										$imageModel->setImage($post_data['oldimage'][$i]);
										$imageModel->setLocationId($model->getId());
										$imageModel->setAddedDate(now());
										$imageModel->save();
									}
								}
							}
						}						
						if(isset($post_data['delete_image']) && $post_data['delete_image'] != '') {
							$deleteIds = substr($post_data['delete_image'],0,-1);
							$deleteImages = explode(",",$deleteIds);
							if(count($deleteImages) > 0) {
								for($d=0;$d<count($deleteImages);$d++) {
									$resource = Mage::getSingleton("core/resource");
									$write = $resource->getConnection("core_write");
									$select = "select image from ".$resource->getTableName('locations/locationsimage')." where locationsimage_id = '".$deleteImages[$d]."'";
									$rs = $write->fetchRow($select);
									if($rs['image']) {
										unlink(Mage::helper("locations")->getGalleryPath().$rs['image']);
									}
									$delete = "delete from ".$resource->getTableName('locations/locationsimage')." where locationsimage_id = '".$deleteImages[$d]."'";
									$rs_delete = $write->query($delete);
								}
							}
						}
						
						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Locations was successfully saved"));
						Mage::getSingleton("adminhtml/session")->setLocationsData(false);

						if ($this->getRequest()->getParam("back")) {
							$this->_redirect("*/*/edit", array("id" => $model->getId()));
							return;
						}
						$this->_redirect("*/*/");
						return;
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						Mage::getSingleton("adminhtml/session")->setLocationsData($this->getRequest()->getPost());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					return;
					}

				}
				$this->_redirect("*/*/");
		}



		public function deleteAction()
		{
				if( $this->getRequest()->getParam("id") > 0 ) {
					try {
						$model = Mage::getModel("locations/locations");
						$model->setId($this->getRequest()->getParam("id"))->delete();
						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item was successfully deleted"));
						$this->_redirect("*/*/");
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					}
				}
				$this->_redirect("*/*/");
		}

		
		public function massRemoveAction()
		{
			try {
				$ids = $this->getRequest()->getPost('location_ids', array());
				foreach ($ids as $id) {
                      $model = Mage::getModel("locations/locations");
					  $model->setId($id)->delete();
				}
				Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item(s) was successfully removed"));
			}
			catch (Exception $e) {
				Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
			}
			$this->_redirect('*/*/');
		}
			
		/**
		 * Export order grid to CSV format
		 */
		public function exportCsvAction()
		{
			$fileName   = 'locations.csv';
			$grid       = $this->getLayout()->createBlock('locations/adminhtml_locations_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
		} 
		/**
		 *  Export order grid to Excel XML format
		 */
		public function exportExcelAction()
		{
			$fileName   = 'locations.xml';
			$grid       = $this->getLayout()->createBlock('locations/adminhtml_locations_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
		}
}
