<?php
//Standard
class Hsk_Locations_Controller_Router extends Mage_Core_Controller_Varien_Router_Abstract
{
    /**
     * Initialize Controller Router
     *
     * @param Varien_Event_Observer $observer
     */
    public function initControllerRouters($observer)
    {
        // @var $front Mage_Core_Controller_Varien_Front 
        $front = $observer->getEvent()->getFront();
        $front->addRouter('locations', $this);
    }

    /**
     * Validate and Match Cms Page and modify request
     *
     * @param Zend_Controller_Request_Http $request
     * @return bool
     */
    public function match(Zend_Controller_Request_Http $request)
    {
        if (!Mage::isInstalled()) {
            Mage::app()->getFrontController()->getResponse()
                ->setRedirect(Mage::getUrl('install'))
                ->sendResponse();
            exit;
        }

        $identifier = trim($request->getPathInfo(), '/');

        $condition = new Varien_Object(array(
            'identifier' => $identifier,
            'continue'   => true
        ));
        Mage::dispatchEvent('locations_controller_router_match_before', array(
            'router'    => $this,
            'condition' => $condition
        ));
        $identifier = $condition->getIdentifier();

        if ($condition->getRedirectUrl()) {
            Mage::app()->getFrontController()->getResponse()
                ->setRedirect($condition->getRedirectUrl())
                ->sendResponse();
            $request->setDispatched(true);
            return true;
        }

        if (!$condition->getContinue()) {
            return false;
        }
		$requestUrl = explode("/",$identifier);
		$params = explode("-",$requestUrl[1]);
		$urlkey = $requestUrl[1];
		$action = 'view';
		//print_r($params);die;
		if(is_array($params) && count($params) > 1) {
			$action = ($params[0] == 'rocketboy') ? 'order' : 'view';
			$urlkey = $params[1];
		}else{		   
		   $urlkey = $params[0];		
		}

        $locations = Mage::getModel('locations/locations');
        $url_key = $locations->checkIdentifier($urlkey);
        if (!$url_key) {
            return false;
        }

        $request->setModuleName('locations')
            ->setControllerName('index')
            ->setActionName($action)
            ->setParam('url_key', $url_key);
        $request->setAlias(
            Mage_Core_Model_Url_Rewrite::REWRITE_REQUEST_PATH_ALIAS,
            $identifier
        );

        return true;
    }
}
