<?php

class Hsk_Locations_Model_Observer
{	//https://www.ybizz.com/blog/add-product-to-cart-with-custom-price-in-magento/#.Vz_yFjV96M-
	/**
 * @param Varien_Event_Observer $observer
 */
public function applyDiscount(Varien_Event_Observer $observer)
{ 

//die('abc');
    /* @var $item Mage_Sales_Model_Quote_Item */
	$quote = $observer->getQuote(); 
    $item = $observer->getQuoteItem();
    if ($item->getParentItem()) {
        $item = $item->getParentItem();
    }
return;
    // Discounted 25% off
    $percentDiscount = 0.25; 
	echo '<pre>';print_r($item->getProduct()->getData());
echo $item->getProduct()->getFinalPrice();die;
    // This makes sure the discount isn't applied over and over when refreshing
    $specialPrice = $item->getProduct()->getPrice() - ($item->getProduct()->getPrice() * $percentDiscount);
//echo $specialPrice;die;
    // Make sure we don't have a negative
    if ($specialPrice > 0) {
        $item->setCustomPrice($specialPrice);
        $item->setOriginalCustomPrice($specialPrice);
        $item->getProduct()->setIsSuperMode(true);
	//	$quote->save();
    }
}

	public function setProductFinalPrice(Varien_Event_Observer $observer)
	{die('abc');
		$event = $observer->getEvent();
		$product = $event->getProduct();
		echo $product->getId();die;
		$product->setFinalPrice(3);
		return $product;
	}

}
	 