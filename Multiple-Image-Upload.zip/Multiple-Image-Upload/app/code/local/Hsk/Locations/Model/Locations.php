<?php

class Hsk_Locations_Model_Locations extends Mage_Core_Model_Abstract
{
    const STATUS_ENABLE       = 1;
    const STATUS_DISABLE      = 2;
    protected function _construct(){

       $this->_init("locations/locations");

    }
	
	public function checkIdentifier($identifier)
    {
        return $this->_getResource()->checkIdentifier($identifier);
    }

}
	 