<?php

class Hsk_Locations_Model_Locationsimage extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("locations/locationsimage");

    }

}
	 