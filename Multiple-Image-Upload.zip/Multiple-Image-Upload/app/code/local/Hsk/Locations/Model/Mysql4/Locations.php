<?php
class Hsk_Locations_Model_Mysql4_Locations extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("locations/locations", "location_id");
    }
	
	public function checkIdentifier($identifier)
    {
        //$stores = array(Mage_Core_Model_App::ADMIN_STORE_ID, $storeId);
        $select = $this->_getLoadByIdentifierSelect($identifier,1);
        $select->reset(Zend_Db_Select::COLUMNS)
            ->columns('cp.url_key')
            ->limit(1);
	//echo $select;
	//$result = $this->_getReadAdapter()->fetchOne($select);
//print_r($result);die;
        return $this->_getReadAdapter()->fetchOne($select);
    }
	
	protected function _getLoadByIdentifierSelect($identifier, $isActive = null)
    {
        $select = $this->_getReadAdapter()->select()
            ->from(array('cp' => $this->getMainTable()))            
            ->where('cp.url_key = ?', $identifier);
        if (!is_null($isActive)) {
            $select->where('cp.status = ?', $isActive);
        }

        return $select;
    }
	
	protected function _beforeDelete(Mage_Core_Model_Abstract $object)
    {
       $writeAdapter = $this->_getWriteAdapter();
	   $delete = "delete from hsk_locationsimage where location_id = '".$object->getId()."'";
	   $writeAdapter->query($delete);
        return parent::_beforeDelete($group);
    }
}