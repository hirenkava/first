<?php
    class Hsk_Locations_Model_Mysql4_Locationsimage_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("locations/locationsimage");
		}

		

    }
	 