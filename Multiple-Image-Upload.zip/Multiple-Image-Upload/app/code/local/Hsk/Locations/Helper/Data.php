<?php
class Hsk_Locations_Helper_Data extends Mage_Core_Helper_Abstract
{
	public function getGalleryUrl()
	{
		return Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/locations/gallery/';
	}
	
	public function getGalleryPath()
	{
		return Mage::getBaseDir('media'). DS .'locations'. DS .'gallery'.DS;
	}
	
	public function getLogoUrl()
	{
		return Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA);
	}
	
	public function getLogoPath()
	{
		return Mage::getBaseDir('media'). DS;
	}
	
	public function getStatuses()
    {
        return array(
            Hsk_Locations_Model_Locations::STATUS_ENABLE     => $this->__('Enable'),
            Hsk_Locations_Model_Locations::STATUS_DISABLE      => $this->__('Disable'),
        );
    }
	
	public function getStatusesOptionArray()
    {
        $result = array();
        foreach ($this->getStatuses() as $k => $v) {
            $result[] = array('value' => $k, 'label' => $v);
        }

        return $result;
    }
}
	 