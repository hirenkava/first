<?php   
class Hsk_Locations_Block_View extends Mage_Core_Block_Template
{
	protected $_location = null;
	public function _construct()
	{
		$url_key = $this->getRequest()->getParam('url_key','');
		if(is_null($this->_location)) {
			$this->_location = Mage::getModel("locations/locations")->load($url_key,'url_key');
		}
		return $this->_location;
	}
	
	public function getLocationCollection()
	{	
		$url_key = $this->getRequest()->getParam('url_key','');
		$locationCollection = Mage::getModel("locations/locations")->getCollection();
		$locationCollection->getSelect()->reset(Zend_Db_Select::COLUMNS)->columns('location_name');
		$locationCollection->getSelect()->join(array('location_image'=>'hsk_locationsimage'),'main_table.location_id = location_image.location_id',array('locationsimage_id','image','sort_order'));
		$locationCollection->addFieldToFilter('url_key',array('eq'=>$url_key));
		
		$locationCollection->getSelect()->order('sort_order','asc');
		//echo $locationCollection->getSelect();die;
		$this->_locationCollection = $locationCollection;	
		return $this->_locationCollection;
	}
	
	public function getLocation()
	{
		return $this->_location;
	}	
}