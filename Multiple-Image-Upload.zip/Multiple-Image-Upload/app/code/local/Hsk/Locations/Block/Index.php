<?php   
class Hsk_Locations_Block_Index extends Mage_Core_Block_Template
{
	public function getLocations()
	{
		$post_code = $this->getRequest()->getPost('postcode','');
		$collection = Mage::getModel("locations/locations")->getCollection();		
		$collection->addFieldToFilter('status',array('eq'=>1));
		if($post_code) {
			$collection->addFieldToFilter('main_table.postcode',array('lteq'=>$post_code));
			$collection->getSelect()->order('main_table.postcode DESC');
			$collection->getSelect()->limit(1);
		}
		//echo $collection->getSelect();
		return $collection;
	}	
}