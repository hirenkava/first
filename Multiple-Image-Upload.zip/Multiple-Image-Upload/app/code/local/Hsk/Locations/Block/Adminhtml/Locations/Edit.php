<?php
	
class Hsk_Locations_Block_Adminhtml_Locations_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
		public function __construct()
		{

				parent::__construct();
				$this->_objectId = "location_id";
				$this->_blockGroup = "locations";
				$this->_controller = "adminhtml_locations";
				$this->_updateButton("save", "label", Mage::helper("locations")->__("Save Location"));
				$this->_updateButton("delete", "label", Mage::helper("locations")->__("Delete Location"));

				$this->_addButton("saveandcontinue", array(
					"label"     => Mage::helper("locations")->__("Save And Continue Edit"),
					"onclick"   => "saveAndContinueEdit()",
					"class"     => "save",
				), -100);



				$this->_formScripts[] = "

							function saveAndContinueEdit(){
								editForm.submit($('edit_form').action+'back/edit/');
							}
						";
		}

		public function getHeaderText()
		{
				if( Mage::registry("locations_data") && Mage::registry("locations_data")->getId() ){

				    return Mage::helper("locations")->__("Edit Location '%s'", $this->htmlEscape(Mage::registry("locations_data")->getLocationName()));

				} 
				else{

				     return Mage::helper("locations")->__("Add Location");

				}
		}
}