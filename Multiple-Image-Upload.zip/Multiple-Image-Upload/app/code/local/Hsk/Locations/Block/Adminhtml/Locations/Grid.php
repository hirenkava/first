<?php

class Hsk_Locations_Block_Adminhtml_Locations_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

		public function __construct()
		{
				parent::__construct();
				$this->setId("locationsGrid");
				$this->setDefaultSort("location_id");
				$this->setDefaultDir("DESC");
				$this->setSaveParametersInSession(true);
		}

		protected function _prepareCollection()
		{
				$collection = Mage::getModel("locations/locations")->getCollection();
				$this->setCollection($collection);
				return parent::_prepareCollection();
		}
		protected function _prepareColumns()
		{
				$this->addColumn("location_id", array(
				"header" => Mage::helper("locations")->__("ID"),
				"align" =>"right",
				"width" => "50px",
			    "type" => "number",
				"index" => "location_id",
				));
				
				$this->addColumn('location_name',
					array(
						'header'=> Mage::helper('locations')->__('Location Name'),
						'index' => 'location_name',
				));
				
				$this->addColumn('postcode',
					array(
						'header'=> Mage::helper('locations')->__('Postcode'),
						'index' => 'postcode',
				));
				
				$this->addColumn('opening_times',
					array(
						'header'=> Mage::helper('locations')->__('Opening Times'),						
						'index' => 'opening_times',
				));
				
				$this->addColumn('added_date', array(
					'header'    => Mage::helper('locations')->__('Added Date'),
					'type'      => 'datetime',
					'align'     => 'center',
					'index'     => 'added_date',
					'gmtoffset' => true
				));
				
				$this->addColumn('action',
            array(
                'header'    =>  Mage::helper('locations')->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('locations')->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
                
			$this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV')); 
			$this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

				return parent::_prepareColumns();
		}

		public function getRowUrl($row)
		{
			   return $this->getUrl("*/*/edit", array("id" => $row->getId()));
		}


		
		protected function _prepareMassaction()
		{
			$this->setMassactionIdField('location_id');
			$this->getMassactionBlock()->setFormFieldName('location_ids');
			$this->getMassactionBlock()->setUseSelectAll(true);
			$this->getMassactionBlock()->addItem('remove_locations', array(
					 'label'=> Mage::helper('locations')->__('Remove Locations'),
					 'url'  => $this->getUrl('*/adminhtml_locations/massRemove'),
					 'confirm' => Mage::helper('locations')->__('Are you sure?')
				));
			return $this;
		}
			

}