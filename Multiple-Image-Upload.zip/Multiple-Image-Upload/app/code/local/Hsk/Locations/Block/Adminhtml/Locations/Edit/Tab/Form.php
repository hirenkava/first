<?php
class Hsk_Locations_Block_Adminhtml_Locations_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("locations_form", array("legend"=>Mage::helper("locations")->__("Location Information")));

				$fieldset->addField('location_name', 'text', array(
					'name'      => 'location_name',
					'label'     => Mage::helper('locations')->__('Location Name'),
					'title'     => Mage::helper('locations')->__('Location Name'),
					'required'  => true,
				));
				
				$fieldset->addField('url_key', 'text', array(
					'name'      => 'url_key',
					'label'     => Mage::helper('locations')->__('URL Key'),
					'title'     => Mage::helper('locations')->__('URL Key'),
					'required'  => true,
				));
				
				$fieldset->addField('postcode', 'text', array(
					'name'      => 'postcode',
					'label'     => Mage::helper('locations')->__('Postcode'),
					'title'     => Mage::helper('locations')->__('Postcode'),
					'required'  => true,
				));
				
				$fieldset->addField('country', 'text', array(
					'name'      => 'country',
					'label'     => Mage::helper('locations')->__('Country'),
					'title'     => Mage::helper('locations')->__('Country'),
					'required'  => true,
				));
				
				$fieldset->addField('phone', 'text', array(
					'name'      => 'phone',
					'label'     => Mage::helper('locations')->__('Phone'),
					'title'     => Mage::helper('locations')->__('Phone'),
					'required'  => true,
				));
				
				$fieldset->addField('logo', 'image', array(
					'name'      => 'logo',
					'label'     => Mage::helper('locations')->__('Logo'),
					'title'     => Mage::helper('locations')->__('Logo'),
					'required'  => false,
				));
				
				$fieldset->addField('opening_times', 'text', array(
					'name'      => 'opening_times',
					'label'     => Mage::helper('locations')->__('Opening Times'),
					'title'     => Mage::helper('locations')->__('Opening Times'),
					'required'  => true,
				));
				
				$fieldset->addField('latitude', 'text', array(
					'name'      => 'latitude',
					'label'     => Mage::helper('locations')->__('Latitude'),
					'title'     => Mage::helper('locations')->__('Latitude'),
					'required'  => true,
				));
				
				$fieldset->addField('longitude', 'text', array(
					'name'      => 'longitude',
					'label'     => Mage::helper('locations')->__('Longitude'),
					'title'     => Mage::helper('locations')->__('Longitude'),
					'required'  => true,
				));
				
				$fieldset->addField('parking', 'textarea', array(
					'name'      => 'parking',
					'label'     => Mage::helper('locations')->__('Parking'),
					'title'     => Mage::helper('locations')->__('Parking'),
					'required'  => true,
				));
				
				$fieldset->addField('address', 'textarea', array(
					'name'      => 'address',
					'label'     => Mage::helper('locations')->__('Address'),
					'title'     => Mage::helper('locations')->__('Address'),
					'required'  => true,
				));
				
				$fieldset->addField('the_vibe', 'textarea', array(
					'name'      => 'the_vibe',
					'label'     => Mage::helper('locations')->__('The Vibe'),
					'title'     => Mage::helper('locations')->__('The Vibe'),
					'required'  => true,
				));
				
				$fieldset->addField('status', 'select', array(
					'label'     => Mage::helper('locations')->__('Status'),
					'required'  => true,
					'name'      => 'status',
					'values'    => Mage::helper('locations')->getStatusesOptionArray(),
				));

				if (Mage::getSingleton("adminhtml/session")->getLocationsData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getLocationsData());
					Mage::getSingleton("adminhtml/session")->setLocationsData(null);
				} 
				elseif(Mage::registry("locations_data")) {
				    $form->setValues(Mage::registry("locations_data")->getData());
				}
				return parent::_prepareForm();
		}
}
