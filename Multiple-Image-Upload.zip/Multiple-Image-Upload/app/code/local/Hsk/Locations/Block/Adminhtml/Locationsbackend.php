<?php  

class Hsk_Locations_Block_Adminhtml_Locationsbackend extends Mage_Adminhtml_Block_Template {

}