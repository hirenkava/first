<?php   
class Hsk_Locations_Block_Rocketboyproductlist extends Mage_Core_Block_Template
{
	public function getPageTitle()
	{
		$data = $this->getRequest()->getParams();
		$pageTitle = 'Rocketboy '.ucfirst($data['url_key']);
		return $pageTitle;
	}
	
	public function getLocation()
	{
		$url_key = $this->getRequest()->getParam('url_key','');
		$location = Mage::getModel('locations/locations')->load($url_key,'url_key');
		return $location;
	}
}